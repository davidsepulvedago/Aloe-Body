Aloe Body - sitio estático de una sola página

Cómo publicar un link público en 30 segundos:
1) Ve a https://app.netlify.com/drop
2) Arrastra y suelta este archivo index.html (o la carpeta completa) en la página.
3) Netlify te dará un enlace público inmediato. ¡Listo!

Alternativas:
- GitHub Pages: crea un repo, sube index.html y habilita Pages.
- Vercel: crea un proyecto nuevo y sube index.html como sitio estático.
